package p

type BasicAlias = uint8
