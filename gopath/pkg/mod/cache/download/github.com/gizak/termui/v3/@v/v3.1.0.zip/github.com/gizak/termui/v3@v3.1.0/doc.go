// Copyright 2017 Zack Guo <zack.y.guo@gmail.com>. All rights reserved.
// Use of this source code is governed by a MIT license that can
// be found in the LICENSE file.

/*
Package termui is a library for creating terminal user interfaces (TUIs) using widgets.
*/
package termui
