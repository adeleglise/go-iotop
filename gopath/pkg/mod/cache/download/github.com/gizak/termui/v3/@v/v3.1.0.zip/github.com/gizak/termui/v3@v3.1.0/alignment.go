package termui

type Alignment uint

const (
	AlignLeft Alignment = iota
	AlignCenter
	AlignRight
)
